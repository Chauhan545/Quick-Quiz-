
package quiz;
import javax.swing.*;
import java.awt.*;  //for changing color //import colour class
import java.awt.event.*;


public class Rules extends JFrame implements ActionListener{
    
    String name;
    JButton start, back;
    
    Rules(String name){
        
        this.name=name;
        
        //to change color
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        
        JLabel heading = new JLabel("Welcome  " + name + "  to  Java  Quiz");
        heading.setBounds(50, 20, 800, 30);
        heading.setFont(new Font("italic", Font.BOLD, 30));
        heading.setForeground(new Color(30, 144, 254));
        add(heading);
        
        //all rules of quiz
        JLabel rules = new JLabel("Welcome  " + name + "  to  Java  Quiz");
        rules.setBounds(20, 70, 700, 350);
        rules.setFont(new Font("italic", Font.PLAIN, 16));
        rules.setText(
        "<html>"+ 
                "1. In this java Quiz test you have given 10 questions." + "<br><br>" +
                "2. Each Question carry 1 mark." + "<br><br>" +
                "3. Once you move to the other question you can not go back to the previous one." + "<br><br>" +
                "4. Time to complete each question is 1 minute." + "<br><br>" +
                "5. If you will not mark your choice within 20 seconds it will automatically switch to the next question." + "<br><br>" +
                "6. Your score will be displayed to you at last." + "<br><br>" +
                
                "7. Good Luck!"+ "<br><br>" +
            "<html>"
        );
        add(rules);
        
        
        //back button from rules
        back = new JButton("Back");
        back.setBounds(250, 400, 100, 30);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        add(back);

        
        //start button
        start = new JButton("Start");
        start.setBounds(400, 400, 100, 30);
        start.setBackground(new Color(30, 144, 254));
        start.setForeground(Color.WHITE);
        start.addActionListener(this);
        add(start);
        
        setSize(1200,700);
        setLocation(200,100);
        setVisible(true);
        
       
    }
    
     public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == start) {
            setVisible(false);
            new Quiz(name);
        } else {
            setVisible(false);
            new Login();
        }
    }
    
   public static void main(String[] args) {
        new Rules("User");
        
    } 
}
