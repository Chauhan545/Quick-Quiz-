
package quiz;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Score extends JFrame implements ActionListener {
    
    JButton exit;
    
    Score(String name, int score) {
        
        setBounds(300, 150, 1000, 500);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/sss.jpg"));
        Image i2 = i1.getImage().getScaledInstance(400, 450, Image.SCALE_DEFAULT);//scaling the image
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 60, 650, 500);
        add(image);

        JLabel heading = new JLabel("Thankyou for playing java Quiz");
        heading.setBounds(45, 30, 700, 30);
        heading.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(heading);

        JLabel lblscore = new JLabel("Your score is " + score);
        lblscore.setBounds(590, 200, 300, 30);
        lblscore.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(lblscore);

         JButton submit = new JButton("Play Again");
        submit.setBounds(610, 250, 120, 30);
        submit.setBackground(new Color(30, 144, 255));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        add(submit);
        
        exit = new JButton("Exit");
        exit.setBounds(750, 250, 120, 30);
        exit.setBackground(new Color(30, 144, 255));
        exit.setForeground(Color.WHITE);
        exit.addActionListener(this);
        add(exit);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        if(ae.getSource() == exit){
            setVisible(false);
        }
        else
        new Login();
        
    }

    public static void main(String[] args) {
        new Score("User", 0);
    }
}