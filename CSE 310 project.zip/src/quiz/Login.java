//import java.awt.Color;
package quiz;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.Pattern;
import quiz.Rules;

public class Login extends JFrame implements ActionListener {
    //globally declared buttons
    JButton rules, back;
    JTextField tfname;
    
    Login(){
        
        getContentPane().setBackground(Color.WHITE);
        //forming my own layout
        setLayout(null);
        
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/login.jpg"));
        
        //placing image component on the frame
        
        //obj of j label class
        JLabel image=new JLabel(i1);
        image.setBounds(0,0,600,640);
        add(image);
        
        //headings
        JLabel heading=new JLabel("java Quiz");
        heading.setBounds(800,60,300,45);
        heading.setFont(new Font("Viner Hand ITC",Font.BOLD,40));
        heading.setForeground(new Color(30,144,254));
        add(heading);
        
        //label for entering name
        JLabel name = new JLabel("Enter your name");
        name.setBounds(810, 150, 300, 50);
        name.setFont(new Font("Mongolian Baiti", Font.BOLD, 18));
        name.setForeground(new Color(30, 144, 254));
        add(name);
        
        
        
        //creating textbox for name entry
         tfname=new JTextField();
        tfname = new JTextField();
        tfname.setBounds(735, 210, 300, 30);
        tfname.setFont(new Font("Times New Roman", Font.BOLD, 15));
        add(tfname);
        
        //creating button for rules
        
         rules = new JButton("Rules");
        rules.setBounds(735, 280, 120, 30);
        rules.setBackground(new Color(30, 144, 254));
        rules.setForeground(Color.WHITE); //changing color of text in rules to white
        rules.addActionListener(this);
        add(rules);
        
        //creating button for back
         back = new JButton("Back");
        back.setBounds(900, 280, 120, 30);
        back.setBackground(new Color(30, 144, 254));
        back.setForeground(Color.WHITE);
        back.addActionListener(this);//told us that action has been performed in this button
        add(back);
        
        setSize(1200,640);
        setLocation(140,100);
        setVisible(true);
    }
    
    //over riding the unimplemented action Listener method
    public void actionPerformed(ActionEvent ae){
        
        if (ae.getSource() == back) {
            setVisible(false);
        }
        else if (!(Pattern.matches("[A-Z][a-zA-Z]+([ '-][a-zA-Z]+)*", tfname.getText()))||!(Pattern.matches("[A-Z][a-zA-Z]*", tfname.getText()))) 
{
            JOptionPane.showMessageDialog(null, "Please enter a valid name", "Error", JOptionPane.ERROR_MESSAGE);

            }
        
        else if(ae.getSource() == rules) {
            String name = tfname.getText();
            setVisible(false);
            new Rules(name);
        }
        
       
    }
    
    public static void main(String[] args){
        new Login();//ananomous object
        
    }
}
